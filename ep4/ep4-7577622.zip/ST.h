void STinit();
void STdelete(Key);
void STinsert(Item);
Item STsearch(Key, int);
void STsort(void (*visit)(Item, int), int);
